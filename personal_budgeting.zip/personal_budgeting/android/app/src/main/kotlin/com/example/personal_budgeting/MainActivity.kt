package com.example.personal_budgeting

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
