const bold ="assets/fonts/sans_bold.ttf";
const regular ="assets/fonts/sans_regular.ttf";
const semibold ="assets/fonts/sans_semibold.ttf";