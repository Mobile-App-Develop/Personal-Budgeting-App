import 'package:personal_budgeting/consts/consts.dart';

//catrory list

const catagorieslist = [
  foods,
  entertainment,
  bills,
];
const catagoriesimg = [
  food,
  enter,
  bill,
];
const itemButtonDetail = [vedio, review, salepoliy, returnpolicy];
