//icons
const food = "assets/images/food.jpg";
const imgBackground = "assets/icons/bg.png";
const icHome = "assets/images/home.png";
const icCategories = "assets/images/categories1.png";
const icCategories2 = "assets/categories2.png";
const expensive = "aexpensive.png";

const enter = "assets/images/enter.png";
const bill = "assets/images/bill.JPG";
const logos = "assets/images/logo.png";
const icSquareLogo = "assets/icons/square_logo.png";
const icTodaysDeal = "assets/images/budget.png";
const icTopCategories = "assets/icons/top_categories.png";
const icTopSeller = "assets/icons/top_sellers.png";
const icTrash = "assets/icons/trash.png";
const icTwitterLogo = "assets/icons/twitter_logo.png";
const icWallet = "assets/icons/wallet.png";
const icWhiteTick = "assets/icons/white_tick.png";
const icWholeSale = "assets/icons/wholesale.png";
const icSplashBg =
    "assets/images/splash_login_registration_background_image.png";
const icFlashDeal = "assets/images/flash_deal.png";
