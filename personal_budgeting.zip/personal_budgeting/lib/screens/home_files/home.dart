import 'package:personal_budgeting/consts/consts.dart';

class homes extends StatefulWidget {
  const homes({super.key});

  @override
  State<homes> createState() => _homeState();
}

class _homeState extends State<homes> {
  @override
  Widget build(BuildContext context) {
    var controller = Get.put(ProductController());

    return Expanded(
      child: SingleChildScrollView(
        physics: const BouncingScrollPhysics(),
        child: Column(children: [
          10.heightBox,
          Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: List.generate(
                  2,
                  (index) => homeButton(
                      height: context.screenHeight * 0.15,
                      width: context.screenWidth / 2.5,
                      icon: index == 0 ? icTodaysDeal : expensive,
                      title: index == 0 ? todayadeal : flashsale))),

          Container(
            padding: EdgeInsets.all(12),
            child: GridView.builder(
                shrinkWrap: true,
                itemCount: 3,
                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 1,
                    mainAxisSpacing: 0,
                    crossAxisSpacing: 0,
                    mainAxisExtent: 150),
                itemBuilder: (context, index) {
                  return Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Image.asset(
                        catagoriesimg[index],
                        height: 75,
                        width: 75,
                        fit: BoxFit.cover,
                      ),
                      10.heightBox,
                      "${catagorieslist[index]}"
                          .text
                          .color(darkFontGrey)
                          .align(TextAlign.center)
                          .make()
                    ],
                  )
                      .box
                      .white
                      .roundedSM
                      .clip(Clip.antiAlias)
                      .outerShadow
                      .make()
                      .onTap(() {
                    controller.getSubCatagories(catagorieslist[index]);
                    Get.to(() => catagoryDetail(title: catagorieslist[index]));
                  });
                }),
          ),

          //All products section
        ]),
      ),
    );
  }
}
